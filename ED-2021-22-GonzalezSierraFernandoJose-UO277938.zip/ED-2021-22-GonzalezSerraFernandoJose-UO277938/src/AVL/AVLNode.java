package AVL;

public class AVLNode <T extends Comparable <T>>{

	private T info; //contenido del nodo generico
	private AVLNode<T> left;//nodo hijo izquierdo
	private AVLNode<T> right;//nodo hijo derecho
	private int height; //altura del nodo
	private int balanceFactor; //factor de balance del nodo
	
	/**
	 * Constructor que crea un nodo con clave dada por parametro, hijo izquierdo y derecho null,
	 * 	y factor de balance y altura 0.
	 * @param clave contenido del nodo de tipo generico
	 */
	public AVLNode(T clave) {
		setInfo(clave);
		this.left=null;
		this.right=null;
		setBalanceFactor(0);
		setHeight(0);
	}
	
	/**
	 * Metodo que devuelve el valor del atributo info
	 * @return valor de info
	 */
	public T getInfo() {
		return info;
	}
	/**
	 * Metodo que asigna al atributo info la dada por parametro
	 * @param clave 
	 */
	public void setInfo(T info) {
		this.info = info;
	}

	/**
	 * Metodo que nos devuelve el nodo izquierdo
	 * @return el nodo izquierdo
	 */
	public AVLNode<T> getLeft() {
		return left;
	}

	/**
	 * Metodo que sustituye el nodo izquierdo por el dado por parametro
	 * @param left nuevo nodo izquierdo
	 */
	public void setLeft(AVLNode<T> left) {
		this.left = left;
	}

	/**
	 * Metodo que nos devuelve el nodo derecho
	 * @return el nodo derecho
	 */
	public AVLNode<T> getRight() {
		return right;
	}

	/**
	 * Metodo que sustituye el nodo derecho por el dado por parametro
	 * @param right nuevo nodo derecho
	 */
	public void setRight(AVLNode<T> right) {
		this.right = right;
	}

	/**
	 * Metodo que devuelve la altura del nodo
	 * @return altura del nodo
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Metodo que sustituye el valor de altura por el dado por parametro
	 * @param height nuevo valor de altura
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Metodo que nos devuelve el valor del factor de balance
	 * @return el factor de balance
	 */
	public int getBalanceFactor() {
		return balanceFactor;
	}

	/**
	 * Metodo que sustituye el valor del factor de balance por el dado por parametro
	 * @param balanceFactor nuevo factor de balance
	 */
	public void setBalanceFactor(int balanceFactor) {
		this.balanceFactor = balanceFactor;
	}
	
	/**
	 * Metodo toString que devuelve una cadena con el estado del objecto
	 */
	public String toString() {
		return info.toString()+ ":BF=" + getBalanceFactor();
	}
	
	/**
	 * Metodo que se llama cada vez que se modifica el nodo, actualizando la altura
	 * 	y el factor de balance
	 */
	public void updateBFHeight() {
		setHeight(1+max(altura(getRight()), altura(getLeft())));
		setBalanceFactor(altura(getRight())-altura(getLeft()));
	}
	
	/**
	 * Metodo que calcula la altura del nodo.
	 * @param nodo a calcular altura
	 * @return -1 si el nodo es null, la altura sino
	 */
	public int altura(AVLNode<T> nodo) {
		if(nodo==null) return -1;
		return nodo.height;
	}
	
	/**
	 * Metodo que calcula el maximo entre dos numeros
	 * @param right valor derecho
	 * @param left valor izquierdo
	 * @return el maximo entre los dos
	 */
	public int max(int right, int left) {
		if(right>=left)
			return right;
		return left;
	}
	
}
