package AVL;

import BST.BSTNode;

public class AVLTree <T extends Comparable<T>> {

	private AVLNode<T> raiz; //nodo raiz del arbol AVL
	
	public AVLTree() {
		raiz=null;
	}
	
	/**
	 * Metodo que busca si existe el nodo en el arbol
	 * @param clave nodo a buscar
	 * @return el nodo si est�, o null si no est�
	 */
	public AVLNode<T> searchNode(T clave){
		if(raiz==null || clave==null)
			return null;
		return searchRecursivo(raiz, clave);
	}
	
	/**
	 * Metodo recursivo que busca un objeto T que sea igual al parametro
	 * @param raiz desde el que partimos
	 * @param clave nodo a buscar
	 * @return el nodo si lo encuentra o null si no lo encuentra
	 */
	private AVLNode<T> searchRecursivo(AVLNode<T> raiz, T clave) {
		if(raiz==null) return raiz;
		if(raiz.getInfo().compareTo(clave)==0) return raiz; //parada que sea igual
		
		if(raiz.getInfo().compareTo(clave)>0) //si clave mayor recursivo por derecha
			return searchRecursivo(raiz.getLeft(), clave); 
		
		else if(raiz.getInfo().compareTo(clave)<0) 
			return searchRecursivo(raiz.getRight(), clave);//si clave es menor recursivo por izquierda
		
		return null; //si no encuentra
	}
	
	/**
	 * Metodo que devuelve el recorrido del arbol de manera preOrder raiz --> izq --> dcha
	 * @return la cadena
	 */
	public String preOrder() {
		if(raiz==null)
			return "";
		return preOrderRecursivo(raiz).substring(0, preOrderRecursivo(raiz).length()-1);
	}
	
	/**
	 * Metodo privado recursivo que crea la cadena con los nodos del arbol
	 * @param raiz donde se llama al metodo
	 * @return la cadena
	 */
	private String preOrderRecursivo(AVLNode<T> raiz) {
		String str = "";

		if(raiz!=null) {
			str+= raiz.toString()+ "\t";
			str+=preOrderRecursivo(raiz.getLeft());
			str+= preOrderRecursivo(raiz.getRight());
		}
		return str;
	}
	
	/**
	 * Metodo que devuelve el recorrido del arbol de manera postOrder izq --> dcha --> raiz
	 * @return la cadena
	 */
	public String postOrder() {
		if(raiz==null)
			return "";
		return postOrderRecursivo(raiz).substring(0, postOrderRecursivo(raiz).length()-1);
	}
	
	private String postOrderRecursivo(AVLNode<T> raiz) {
		String str = "";
		
		if(raiz!=null) { //si no tiene izquierda return
			str+=postOrderRecursivo(raiz.getLeft());
			str+=postOrderRecursivo(raiz.getRight());
			str+=raiz.toString() + "\t";
		}
		return str;
	}

	/**
	 * Metodo que devuelve el recorrido del arbol de manera inOrder  izq --> raiz --> dcha
	 * @return la cadena
	 */
	public String inOrder() {
		if(raiz==null)
			return "";
		return inOrderRecursivo(raiz).substring(0, inOrderRecursivo(raiz).length()-1);
	}
	
	private String inOrderRecursivo(AVLNode<T> raiz) {
		String str = "";
		
		if(raiz!=null) {
			str+=inOrderRecursivo(raiz.getLeft());
			str+=raiz.toString() + "\t";
			str+=inOrderRecursivo(raiz.getRight());
		}
		return str;
	}
	
	/**
	 * Metodo que a�ade un nodo al arbol
	 * @param clave a a�adir
	 * @return -2 si la clave es null, -1 si ya existe el nodo, 0 si lo a�ade correctamente
	 */
	public int addNode(T clave) {
		if(clave==null)	return -2; //-2 si clave null
		else if(searchNode(clave)!=null) return -1; //si ya existe nodo -1
		
		else if(raiz==null) { //si raiz null a�adir clave como nuevo nodo raiz
			AVLNode<T> nodo = new AVLNode<T>(clave);
			this.raiz=nodo;
			raiz=updateAndBalanceIfNecesary(nodo);
			return 0;
		}
		
		raiz = addNodeRecursivo(raiz, clave);
		raiz = updateAndBalanceIfNecesary(raiz);
		//System.out.println(raiz.toString());
		return 0;
		
	}
	
	/**
	 * Metodo privado recursivo que busca la posicion para a�adir el nodo
	 * @param nodo desde el que se empieza a buscar
	 * @param clave del nuevo nodo
	 * @return el nodo para el padre
	 */
	private AVLNode<T> addNodeRecursivo(AVLNode<T> nodo, T clave) {
		
		if(nodo.getInfo().compareTo(clave)>0){		//clave menor recursivo izq
			if(nodo.getLeft()==null) {
				AVLNode<T> nuevoNodo = new AVLNode<T>(clave); //a�ade el nodo a la izquierda
				nodo.setLeft(nuevoNodo);
				nodo=updateAndBalanceIfNecesary(nodo);
				return nodo;
			}
			AVLNode<T> ret =addNodeRecursivo(nodo.getLeft(), clave);
			nodo.setLeft(ret);
			nodo = updateAndBalanceIfNecesary(nodo);
			return nodo;
		}
		
		else {
			if(nodo.getRight()==null) {
				AVLNode<T> nuevoNodo = new AVLNode<T>(clave); //a�ade el nodo a la derecha 
				nodo.setRight(nuevoNodo);
				nodo=updateAndBalanceIfNecesary(nodo);
				
				return nodo;
			}			//clave mayor recurisvo dcha
			AVLNode<T> ret =  addNodeRecursivo(nodo.getRight(), clave);
			nodo.setRight(ret);
			nodo= updateAndBalanceIfNecesary(nodo);
			return nodo;
		}
		
	}
	
	/**
	 * Metodo que actualiza el nodo y ademas hace una o dos rotaciones si es necesario
	 * @param nodo a actualizar y/o rotar
	 * @return el nodo actualizado y/o rotado
	 */
	private AVLNode<T> updateAndBalanceIfNecesary(AVLNode<T> nodo){
		nodo.updateBFHeight();
		if(nodo.getBalanceFactor() == -2) {
			if(nodo.getLeft().getBalanceFactor() == 1)
				nodo = doubleLeftRotation(nodo);
			else
				nodo = singleLeftRotation(nodo);
		}
		else if(nodo.getBalanceFactor() == 2) {
			if(nodo.getRight().getBalanceFactor() == -1)
				nodo = doubleRightRotation(nodo);
			else
				nodo = singleRightRotation(nodo);
		}
		return nodo;
	}
	
	/**
	 * Metodo que rota el arbol, se le llama cuando es necesario rotar hacia la izquierda
	 * @param nodo antigua raiz del arbol
	 * @return el nuevo nodo raiz;
	 */
	private AVLNode<T> singleRightRotation(AVLNode<T> nodo){
		AVLNode<T> supp  = nodo.getRight();
		nodo.setRight(supp.getLeft());
		nodo.updateBFHeight();
		
		supp.setLeft(nodo);
		supp.updateBFHeight();
		
		return supp;
	}
	
	/**
	 * Metodo que rota el arbol, se le llama cuando es necesario rotar hacia la derecha
	 * @param nodo antigua raiz del arbol
	 * @return el nuevo nodo raiz
	 */
	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo){
		AVLNode<T> supp  = nodo.getLeft();
		nodo.setLeft(supp.getRight());
		nodo.updateBFHeight();
		
		supp.setRight(nodo);
		supp.updateBFHeight();
		
		return supp;
	}
	
	/**
	 * Metodo que rota dos veces el arbol, la primera con el hijo izquierdo y luego 
	 * 	con el nodo raiz
	 * @param nodo antigua raiz del arbol
	 * @return el nuevo nodo raiz
	 */
	private AVLNode<T> doubleLeftRotation(AVLNode<T> nodo){
		nodo.setLeft(singleRightRotation(nodo.getLeft()));
		nodo = singleLeftRotation(nodo);
		System.out.println(nodo.toString());
		System.out.println(nodo.getRight().toString());
		return nodo;
		
	}
	
	/**
	 * Metodo que rota dos veces el arbol, la primera con el hijo derecho y luego 
	 * 	con el nodo raiz
	 * @param nodo antigua raiz del arbol
	 * @return el nuevo nodo raiz
	 */
	private AVLNode<T> doubleRightRotation(AVLNode<T> nodo){
		nodo.setRight(singleLeftRotation(nodo.getRight()));
		nodo = singleRightRotation(nodo);
		System.out.println(nodo.toString());
		System.out.println(nodo.getRight().toString());
		System.out.println(nodo.getLeft().toString());
		return nodo;
	}
	
	/**
	 * Metodo que borra el nodo dado por parametro 
	 * @param clave del nodo a borrar
	 * @return -2 si la clave es null o la raiz es null, -1 si no hay nodo con
	 *		esa clave, 0 si lo borra correctamente.
	 */
	public int removeNode(T clave){
		if(clave==null || this.raiz==null) return -2; //clave null o raiz null
		
		if(searchNode(clave)==null) return -1; //no existe 
		
		raiz=removeRecursivo(raiz, clave);
		return 0;
	}
	
	/**
	 * Metodo privado recursivo que busca el nodo de la clave y una vez encotrado lo borra
	 * 	dependiendo de los hijos que tenga.
	 * @param nodo raiz del arbol
	 * @param clave del nodo a borrar
	 * @return el nodo hijo para el padre
	 */
	private AVLNode<T> removeRecursivo(AVLNode<T> nodo, T clave){
		if(nodo.getInfo().compareTo(clave)==0) { //si se encuentra el nodo a borrar
			
			if(nodo.getLeft()==null && nodo.getRight()==null) //si no hay izquierda y derecha
				return null;
			
			if(nodo.getLeft()==null && nodo.getRight()!=null) { //si solo hay derecha
				AVLNode<T> ret = nodo.getRight();
				ret = updateAndBalanceIfNecesary(ret);
				return ret;
			}
			
			else if (nodo.getLeft()!=null && nodo.getRight()==null){//si solo hay izqueirda
				AVLNode<T> ret = nodo.getLeft();
				ret = updateAndBalanceIfNecesary(ret);
				return ret;
			}
			else {  //si hay izquierda y derecha
				AVLNode<T> mayor = buscarMayor(nodo.getLeft());
				nodo.setInfo(mayor.getInfo());
				nodo.setLeft(removeRecursivo(nodo.getLeft(), mayor.getInfo()));
				nodo = updateAndBalanceIfNecesary(nodo);
				return nodo;
			}
		}
		
		//buscar el nodo
		else if(nodo.getInfo().compareTo(clave)>0) { //izquierda
			//asignar al padre
			 nodo.setLeft(removeRecursivo(nodo.getLeft(), clave));
			 nodo = updateAndBalanceIfNecesary(nodo);
		}
		else if(nodo.getInfo().compareTo(clave)<0) { //derecha
			//asignar al padre
			nodo.setRight(removeRecursivo(nodo.getRight(), clave));
			nodo = updateAndBalanceIfNecesary(nodo);
		}
		return nodo;
	}
	
	/**
	 * Metodo que busca el mayor de un arbol, en nuestro caso se usa para el 
	 * 	subarbol izquierdo
	 * @param node desde donde se busca
	 * @return el nodo con mayor info
	 */
	private AVLNode<T> buscarMayor(AVLNode<T> node) {
		
		if(node.getRight()==null)
			return node;
		else
			return buscarMayor(node.getRight());
	}
 
	/**
	 * Metodo que devuelve el padre del nodo de valor clave 
	 * @param clave nodo a buscar para devolver el padre
	 * @return nodo padre o null is no tiene padre o el parametro no existe o arbol es null
	 */
	public AVLNode<T> padreDe(T clave){
		if(raiz==null || clave==null) return null;
		if(searchNode(clave)==null) return null;
		
		if(raiz.getInfo().compareTo(clave)>0) { //izquierda
			//TODO
		}
		return null;
	}
	
	/**
	 * Metodo que devuelve el numero de aristas que hay desde clave1 hasta clave2 teniendo
	 * 	en cuenta que clave1 siempre es ancestro de clave2.
	 * @param clave1 primera clave
	 * @param clave2 segunda clave
	 * @return 0 si cualquiera de las claves es null o si son iguales, el numero de aristas
	 * 	entre ambos sino.
	 */
	public int numAristas(T clave1, T clave2) {
		if(clave1==null || clave2==null || this.raiz==null || clave1.equals(clave2))
			return 0;
		int contador = 0;
		return numAristasRecursivo(searchNode(clave1), clave2, contador);
		
	}
	
	/**
	 * Metodo recursivo que recorre el arbol y va aumentandando un contador por cada llamada recursiva.
	 * @param nodo desde el que se recorre
	 * @param clave2 del nodo a buscar
	 * @param contador que va aumentando
	 * @return el valor de contador
	 */
	private int numAristasRecursivo(AVLNode<T> nodo, T clave2, int contador) {
		if(nodo.getInfo().compareTo(clave2)==0) return contador;
		else if(nodo.getInfo().compareTo(clave2)>0) { //izquierda
			return numAristasRecursivo(nodo, clave2, contador++);
		}else
			return numAristasRecursivo(nodo, clave2, contador++);
	}

}
