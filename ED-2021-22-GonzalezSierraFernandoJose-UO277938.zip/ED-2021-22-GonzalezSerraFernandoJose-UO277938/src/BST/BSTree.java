package BST;

public class BSTree <T extends Comparable<T>>{

	private BSTNode<T> raiz; //nodo raiz del arbol
	
	public BSTree() {
		raiz=null;
	}
	
	/**
	 * Metodo que busca si existe el nodo en el arbol
	 * @param clave nodo a buscar
	 * @return el nodo si est�, o null si no est�
	 */
	public BSTNode<T> searchNode(T clave){
		if(raiz==null || clave==null)
			return null;
		return searchRecursivo(raiz, clave);
	}
	
	/**
	 * Metodo recursivo que busca un objeto T que sea igual al parametro
	 * @param nodo desde el que partimos
	 * @param clave nodo a buscar
	 * @return el nodo si lo encuentra o null si no lo encuentra
	 */
	private BSTNode<T> searchRecursivo(BSTNode<T> nodo, T clave) {
		if(nodo==null) return nodo;
		if(nodo.getInfo().compareTo(clave)==0) return nodo; //parada que sea igual
		
		if(nodo.getInfo().compareTo(clave)>0) //si clave mayor recursivo por derecha
			return searchRecursivo(nodo.getLeft(), clave); 
		
		else if(nodo.getInfo().compareTo(clave)<0) 
			return searchRecursivo(nodo.getRight(), clave);//si clave es menor recursivo por izquierda
		
		return null; //si no encuentra
	}

	/**
	 * Metodo que a�ade un nodo al arbol
	 * @param clave a a�adir
	 * @return -2 si la clave es null, -1 si ya existe el nodo, 0 si lo a�ade correctamente
	 */
	public int addNode(T clave) {
		if(clave==null)	return -2; //-2 si clave null
		else if(searchNode(clave)!=null) return -1; //si ya existe nodo -1
		
		else if(raiz==null) { //si raiz null a�adir clave como nuevo nodo raiz
			BSTNode<T> nodo = new BSTNode<T>(clave);
			this.raiz=nodo;
			return 0;
		}
		
		return addNodeRecursivo(raiz, clave);
	}
	
	/**
	 * Metodo recursivo que busca la posicion correcta para a�adir el nodo
	 * @param nodo desde el que se parte
	 * @param clave del nuevo nodo
	 * @return 0 si lo a�ade
	 */
	private int addNodeRecursivo(BSTNode<T> nodo, T clave) {
		if(nodo==null) {
			BSTNode<T> nuevoNodo = new BSTNode<T>(clave); //a�ade el nodo a la posicion 
			nodo=nuevoNodo;
			
			return 0; //return para volver
		}
		
		if(nodo.getInfo().compareTo(clave)>0){		//clave menor recursivo izq
			if(nodo.getLeft()==null) {
				BSTNode<T> nuevoNodo = new BSTNode<T>(clave); //a�ade el nodo a la posicion 
				nodo.setLeft(nuevoNodo);
				return 0;
			}
			return addNodeRecursivo(nodo.getLeft(), clave);
		}
		
		else {
			if(nodo.getRight()==null) {
				BSTNode<T> nuevoNodo = new BSTNode<T>(clave); //a�ade el nodo a la posicion 
				nodo.setRight(nuevoNodo);
				return 0;
			}			//clave mayor recurisvo dcha
			return addNodeRecursivo(nodo.getRight(), clave);
		}
	}

	/**
	 * Metodo que devuelve el recorrido del arbol de manera preOrder raiz --> izq --> dcha
	 * @return la cadena
	 */
	public String preOrder() {
		if(raiz==null)
			return "";
		return preOrderRecursivo(raiz).substring(0, preOrderRecursivo(raiz).length()-1);
	}
	
	/**
	 * Metodo privado recursivo que crea la cadena con los nodos del arbol
	 * @param raiz donde se llama al metodo
	 * @return la cadena
	 */
	private String preOrderRecursivo(BSTNode<T> raiz) {
		String str = "";

		if(raiz!=null) {
			str+= raiz.toString()+ "\t";
			str+=preOrderRecursivo(raiz.getLeft());
			str+= preOrderRecursivo(raiz.getRight());
		}
		return str;
	}

	/**
	 * Metodo que devuelve el recorrido del arbol de manera postOrder izq --> dcha --> raiz
	 * @return la cadena
	 */
	public String postOrder() {
		if(raiz==null)
			return "";
		return postOrderRecursivo(raiz).substring(0, postOrderRecursivo(raiz).length()-1);
	}
	
	private String postOrderRecursivo(BSTNode<T> raiz) {
		String str = "";
		
		if(raiz!=null) { //si no tiene izquierda return
			str+=postOrderRecursivo(raiz.getLeft());
			str+=postOrderRecursivo(raiz.getRight());
			str+=raiz.toString() + "\t";
		}
		return str;
	}

	/**
	 * Metodo que devuelve el recorrido del arbol de manera inOrder  izq --> raiz --> dcha
	 * @return la cadena
	 */
	public String inOrder() {
		if(raiz==null)
			return "";
		return inOrderRecursivo(raiz).substring(0, inOrderRecursivo(raiz).length()-1);
	}
	
	private String inOrderRecursivo(BSTNode<T> raiz) {
		String str = "";
		
		if(raiz!=null) {
			str+=inOrderRecursivo(raiz.getLeft());
			str+=raiz.toString() + "\t";
			str+=inOrderRecursivo(raiz.getRight());
		}
		return str;
	}

	/**
	 * Metodo que borra un nodo del arbol de grafos, llamando a un metodo removeRecursivo
	 * @param clave informacion del nodo
	 * @return 0 si se borra, -2 si no existe clave o raiz del arbol, -1 si no hay nodo con esa clave
	 */
	public int removeNode(T clave) {
		if(clave==null || raiz == null) return -2;
		
		if(searchNode(clave)==null) return -1;
		
		raiz=removeRecursivo(raiz, clave);
		return 0;
	}

	/**
	 * Metodo recursivo que realiza una accion dependiendo de cuantos hijos tiene
	 * @param raiz de la que empezar a borrar
	 * @param clave a borrar
	 * @return la raiz para actualizar al padre
	 */
	private BSTNode<T> removeRecursivo(BSTNode<T> raiz, T clave) {
		if(raiz.getInfo().compareTo(clave)==0) { //si se encuentra el nodo a borrar
		
			if(raiz.getLeft()==null && raiz.getRight()==null) //si no hay izquierda y derecha
				return null;
			
			if(raiz.getLeft()==null && raiz.getRight()!=null) //si solo hay derecha
				return raiz.getRight();
			
			else if (raiz.getLeft()!=null && raiz.getRight()==null)//si solo hay izqueirda
				return raiz.getLeft();
			
			else {  //si hay izquierda y derecha
				BSTNode<T> mayor = buscarMayor(raiz.getLeft());
				raiz.setInfo(mayor.getInfo());
				raiz.setLeft(removeRecursivo(raiz.getLeft(), mayor.getInfo()));
				
				return raiz;
			}
		}
			//buscar el nodo
		else if(raiz.getInfo().compareTo(clave)>0) { //izquierda
			//asignar al padre
			 raiz.setLeft(removeRecursivo(raiz.getLeft(), clave));
		}
		else if(raiz.getInfo().compareTo(clave)<0) { //derecha
			//asignar al padre
			raiz.setRight(removeRecursivo(raiz.getRight(), clave));
		}
			
		return raiz;
	}

	/**
	 * Metodo que busca el mayor de un arbol, en nuestro caso se usa para el 
	 * 	subarbol izquierdo
	 * @param raiz desde donde se busca
	 * @return el nodo con mayor info
	 */
	private BSTNode<T> buscarMayor(BSTNode<T> raiz) {
		
		if(raiz.getRight()==null)
			return raiz;
		else
			return buscarMayor(raiz.getRight());
	}
	
}
