package ColasPrioridad;

public class Colores implements Comparable<Colores>{

	private String nombre;   // Naranja
	private String codigo;   // #FF8000 sin el '#', 6 digiitos hexadecimales
	
	public Colores(String codigo, String nombre) {
		this.codigo = codigo;
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	@Override
	public int compareTo(Colores c) {
		String[] partes = codigo.split("#");
		String[] partes2 = c.codigo.split("#");

		long cod = Long.parseLong(partes[1], 16);
		long other = Long.parseLong(partes2[1], 16);

		if(cod< other)
			return -1;
		else if(cod> other)
			return 1;
		else
			return 0;
	}
	
	@Override
	public String toString() {
		return "[" + codigo + "/"+ nombre + "]"; 
	}
 }
