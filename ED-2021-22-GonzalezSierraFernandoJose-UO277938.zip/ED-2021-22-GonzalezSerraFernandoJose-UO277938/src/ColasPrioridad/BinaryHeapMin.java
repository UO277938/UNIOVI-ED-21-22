package ColasPrioridad;

public class BinaryHeapMin<T extends Comparable<T>> implements PriorityQueue<T> {

	private T[] monticulo; // vector de elementos de un determinado tama�o

	private int numElementos; // numero de elementos insertados en el vector

	@SuppressWarnings("unchecked")
	public BinaryHeapMin(int n) {
		monticulo = (T []) new Comparable[n];
		numElementos=0;
	}

	/**
	 * A�ade un objeto T al monticulo, en la ultima posicion e incrementa el numero
	 * de elementos y luego filtramos hacia arriba para comprobar que es menor que
	 * su padre.
	 * 
	 * @return -2 si el elemento pasado por parametro es null, -1 si no hay espacio
	 *         en el monticulo sino devuelve 0
	 */
	@Override
	public int add(T elemento) {
		if (elemento == null)
			return -2;
		if (monticulo.length == numElementos)
			return -1;

		monticulo[numElementos] = elemento;
		filtradoAscendente(numElementos);
		numElementos++;
		return 0;
	}

	private void filtradoAscendente(int pos) {
		if (pos >= 0) {
			T padre = monticulo[(pos - 1) / 2];
			T added = monticulo[pos];
			if (added.compareTo(padre) < 0) { // elemento menor que padre
				monticulo[(pos-1) / 2] = added;
				monticulo[pos] = padre;
				filtradoAscendente((pos - 1) / 2);
			}
		}

	}

	private void filtradoDescendente(int pos) {
		if( (pos*2 + 2) >= monticulo.length && (pos*2+1)< monticulo.length) {
			if(monticulo[pos].compareTo(monticulo[pos*2+1])>0) { //padre mayor que uno de sus hijos
				T supp = monticulo[pos];
				monticulo[pos] = monticulo[pos*2+1];
				monticulo[pos*2 + 1] = supp;
				filtradoDescendente(pos * 2 + 1);
			}
		}
		else if (pos*2+2 < monticulo.length) {
			T padre = monticulo[pos];
			T hijoIzquierdo = monticulo[pos * 2 + 1];
			T hijoDerecho = monticulo[pos * 2 + 2];
			if (hijoIzquierdo!=null && hijoDerecho != null && padre.compareTo(hijoIzquierdo) > 0 && padre.compareTo(hijoDerecho) > 0) { // padre mayor que ambos hijos
				if (hijoIzquierdo.compareTo(hijoDerecho) < 0) { // derecha mayor que derecha
					T supp = padre;
					monticulo[pos] = hijoIzquierdo;
					monticulo[pos*2 +1 ] = supp;
					filtradoDescendente(pos * 2 + 1);
				} else {
					
					T supp = padre;
					monticulo[pos] = hijoDerecho;
					monticulo[pos*2 + 2] = supp;
					filtradoDescendente(pos * 2 + 2);
				}
			} else if (hijoDerecho != null &&padre.compareTo(hijoDerecho) > 0) { // padre mayor que
																								// derecho pero no de
																								// izq
				T supp = padre;
				monticulo[pos] = hijoDerecho;
				monticulo[pos*2 + 2] = supp;
				filtradoDescendente(pos * 2 + 2);
			} else if (hijoIzquierdo != null && padre.compareTo(hijoIzquierdo)> 0) { // padre mayor que
																								// izquierdo pero no de
																								// derecho
				T supp = padre;
				monticulo[pos] = hijoIzquierdo;
				monticulo[pos*2 + 1] = supp;
				filtradoDescendente(pos * 2 + 1);
			}
		}

	}

	/**
	 * Almacenar el objecto posicion 0 en una variable, coger el ultimo elemento y ponerlo en la posicion 0,
	 * 	decrementamos el numero de elementos y luego un filtrado descendente. Filtramos mientras se tenga que filtrar.
	 * 
	 * @return la raiz
	 */
	@Override
	public T sacar() {
		T sup = monticulo[0]; //guardamos posicion 0
		monticulo[0] = monticulo [numElementos-1]; //ultimo en posicion 0
		monticulo[numElementos-1] =null;

		
		filtradoDescendente(0);
		numElementos--;

		return sup;
	}

	/**
	 * Elimina de la lista, coloca el ultimo elemento en la del elemento de
	 * parametro
	 * 
	 * @return -2 si elemento es null o el monticulo esta vacio , -1 si no existe el
	 *         parametro en la lista, 0 si lo borra.
	 */
	@Override
	public int remove(T elemento) {
		if(elemento == null || monticulo[0] == null) return -2;
		int index = searchElement(elemento);
		if(index<0) return -1;
		
		monticulo[index] = monticulo[numElementos-1];
		monticulo[numElementos-1] = null;
		
		filtradoDescendente(index);
		numElementos--;
		return 0;
	}
	
	private int searchElement(T elemento) {
		if(elemento == null) return -2;
		for(int i=0; i<numElementos; i++) {
			if(monticulo[i].compareTo(elemento)==0)
				return i;
		}
		return -1;
	}

	/**
	 * Si el numero de elementos es 0 devuelve true, sino false
	 * @return true si esta vacia, false sino
	 */
	@Override
	public boolean isEmpty() {
		if (monticulo[0] == null)
			return true;
		return false;
	}

	/**
	 * Vacia el monticulo.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < numElementos; i++) {
			monticulo[i] = null;
		}
	}

	/**
	 * Cambia el valor de la posicion por el elemento, si es mayor hago un fitrado
	 * hacia abajo, si es menor hago un filtrado hacia arriba.
	 * @return 0 si cambia prioridad, 
	 * 	-2 si el elemento es null o posicion si es imcorrecta
	 * 	-1 si elemento no existe o monticulo vacio o 
	 * 		el elemento a cambiar es igual al de la posicion
	 */
	@Override
	public int cambiarPrioridad(int pos, T elemento) {
		if(elemento == null || pos<0 || pos>numElementos) return -2;
		if(searchElement(elemento)==-2 || isEmpty()) return -1;
		
		T sup = monticulo[pos];
		if(sup.compareTo(elemento)==0) return -1;
		monticulo[pos] = elemento;
		
		if(sup.compareTo(elemento)>0) 
			filtradoAscendente(pos);
		
		else if(sup.compareTo(elemento)<0) 
			filtradoDescendente(pos);
		
		return 0;
	}

	/**
	 * Elementos separados por tabuladores, no hay tabulador final.
	 */
	public String toString() {
		String str = "";
		for(int i = 0; i<numElementos;i++) {
			str+= monticulo[i].toString() + "\t";
		}
		str = str.substring(0, str.length()-1);
		return str;
	}

}