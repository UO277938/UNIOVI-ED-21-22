package ColasPrioridad;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PriorityQueueTests {

	@Test
	void testPriorityQueue() {

		BinaryHeapMin<Integer> m = new BinaryHeapMin<Integer>(7);

		assertEquals(-2, m.remove(5)); //borar monticulo vacio

		assertEquals(0, m.add(2));
		assertEquals(0, m.add(4));
		assertEquals(0, m.add(13));
		assertEquals(0, m.add(6));
		assertEquals(0, m.add(7));
		
		assertEquals("2\t4\t13\t6\t7", m.toString());
		System.out.println(m.toString());
		assertEquals(-1, m.remove(75)); //borra y no esta en monticulo
		assertEquals(0, m.add(10));
		assertEquals("2\t4\t10\t6\t7\t13", m.toString());
		System.out.println(m.toString());
		assertEquals(0, m.remove(4));
		assertEquals("2\t6\t10\t13\t7", m.toString());
		System.out.println(m.toString());
		assertEquals(0, m.add(1));
		assertEquals("1\t6\t2\t13\t7\t10", m.toString());
		System.out.println(m.toString());
		assertEquals(0, m.add(20));
		assertEquals("1\t6\t2\t13\t7\t10\t20", m.toString());
		System.out.println(m.toString());
		assertEquals(-1, m.add(20)); //inserto elemento y no hay espacio
		assertEquals("1\t6\t2\t13\t7\t10\t20", m.toString());
		System.out.println(m.toString());
		assertEquals(1, (int) m.sacar()); //sacar
		assertEquals("2\t6\t10\t13\t7\t20", m.toString());
		System.out.println(m.toString());
	}
	
	@Test
	public void testColores() {
		
		BinaryHeapMin<Colores> m= new BinaryHeapMin<Colores>(7);

				
		assertEquals(-2,m.remove(new Colores("#FF8000","Naranja")));
		
		assertEquals(0,m.add(new Colores("#FF8000","Naranja")));
		assertEquals(0,m.add(new Colores("#FFFFFF","Blanco")));
		assertEquals(0,m.add(new Colores("#0000FF","Azul")));
		assertEquals(0,m.add(new Colores("#00FF00","Verde")));
		assertEquals(0,m.add(new Colores("#000000","Negro")));

		assertEquals("[#000000/Negro]\t[#0000FF/Azul]\t[#FF8000/Naranja]\t[#FFFFFF/Blanco]\t[#00FF00/Verde]",m.toString());
		System.out.println(m.toString());
		
		assertEquals("[#000000/Negro]", m.sacar().toString());
		System.out.println(m.toString());
		
		assertEquals(0, m.remove(new Colores("#00FF00", "Verde")));
		System.out.println(m.toString());

	}

}
