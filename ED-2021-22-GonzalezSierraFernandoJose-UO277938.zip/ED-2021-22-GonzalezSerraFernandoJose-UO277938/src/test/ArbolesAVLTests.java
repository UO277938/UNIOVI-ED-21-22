package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import AVL.AVLNode;

class ArbolesAVLTests {

	@Test
	void testAVL() {
		AVLNode<Integer> n = new AVLNode<Integer>(10);
		System.out.println(n.toString());
		//n.setLeft(new AVLNode<Integer>(2));
		//System.out.println(n.getLeft().toString());
		
		n.setRight(new AVLNode<Integer>(15));
		System.out.println(n.getRight().toString());
		
		System.out.println("Despues de actualizar");
		n.updateBFHeight();
		System.out.println(n.toString());
		System.out.println(n.getRight().toString());
		
		n.getRight().setRight(new AVLNode<Integer> (50));
		System.out.println(n.getRight().getRight().toString());
		
		System.out.println("Despues de actualizar");
		n.getRight().updateBFHeight();
		n.updateBFHeight();
		System.out.println(n.toString());
		System.out.println(n.getRight().toString());
		System.out.println(n.getRight().getRight().toString());
		System.out.println("--------------------------");
	}
}
