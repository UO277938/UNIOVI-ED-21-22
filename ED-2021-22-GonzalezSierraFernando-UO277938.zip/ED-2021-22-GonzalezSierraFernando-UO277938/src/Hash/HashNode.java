package Hash;

public class HashNode <T>{
	
	public static final int BORRADO = -1;
	public static final int VACIO = 0;
	public static final int LLENO = 1;
	
	private T info;
	private int estado;
	
	/**
	 * Constructor sin parametros que iniializa el nodo a vacio y null
	 */
	public HashNode() {
		estado = VACIO;
		setInfo(null);
	}
	/**
	 * Metodo que nos devuelve la informacion 
	 * @return la informacion del nodo
	 */
	public T getInfo() {
		return this.info;
	}
	
	/**
	 * Metodo que cambia el valor de info al dado por parametro
	 * @param elemento nuevo valor de info
	 */
	public void setInfo(T elemento) {
		this.info = elemento;
	}
	
	/**
	 * Cambiamos el estado a borrado.
	 */
	public void remove() {
		this.estado = BORRADO;
	}
	
	/**
	 * Devuelve el estado del objeto
	 * @return el estado
	 */
	public int getStatus() {
		return this.estado;
	}
	
	/**
	 * Metodo que cambia el valor de estado por el dado por parametro
	 * @param estado nuevo valaor de estado
	 */
	public void setStatus(int estado) {
		this.estado= estado;
	}
	
	/**
	 * Metodo toString que nos devuelve el estado del objeto en String
	 */
	public String toString() {
		StringBuilder cadena = new StringBuilder("{");
		switch(getStatus()) {
		case LLENO: 
			cadena.append(info.toString());
			break;
		case VACIO: 
			cadena.append("_E_");
			break;
		case BORRADO:
			cadena.append("_D_");
		}
		cadena.append("}");
		return cadena.toString();
	}
	
}
