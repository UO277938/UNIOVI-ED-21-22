package Hash;

import java.lang.reflect.Array;

public class ClosedHashTable<T> extends AbstractHash<T> {
	
	private static final double MINIMUN_LF = 0.16;
	private static final double MAXIMUM_LF = 0.5;

	private int numElementos; // numero de elementos insertados
	private HashNode<T> tabla[]; // tabla hash
	private int tipoExploracion; // 1-lineal; 2-cuadratica; 3-dispersion doble
	
	private double minlf; //factor de carga minimo
	private double maxlf; //factor de carga maximo

	/**
	 * Constructor con dos parametros para crear una tabla hash cerrada
	 * con valores de carga predeterminados
	 * @param tam tama�o de la tabla
	 * @param tipo de exploracion 
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo) {
		this.numElementos = 0;
		this.tipoExploracion = tipo;
		minlf = MINIMUN_LF;
		maxlf = MAXIMUM_LF;

		if (!isPositivePrime(tam))
			tam = nextPrimeNumber(tipo);
		
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, tam);
		for (int i = 0; i < tam; i++) {
			tabla[i] = new HashNode<T>();
		}
	}
	
	/**
	 * Constructor con cuatro parametros, a diferencia del de dos a este
	 * se le indica los valores de carga
	 * @param tam tmaa�o de la tabla
	 * @param tipo de exploracion
	 * @param minlf nuevo valor de carga minimo
	 * @param maxlf nuevo valor de carga maximo
	 */
	@SuppressWarnings("unchecked")
	public ClosedHashTable(int tam, int tipo, double minlf, double maxlf) {
		this.numElementos = 0;
		this.tipoExploracion = tipo;
		
		this.minlf = minlf;
		this.maxlf = maxlf;

		if (!isPositivePrime(tam))
			tam = nextPrimeNumber(tam);
		
		this.tabla = (HashNode<T>[]) Array.newInstance(HashNode.class, tam);
		for (int i = 0; i < tam; i++) {
			tabla[i] = new HashNode<T>();
		}
	}

	/**
	 * Devuelve el numero de elementos en la tabla
	 */
	@Override
	public int getNumOfElements() {
		return numElementos;
	}

	/**
	 * Devuelve el tama�o de la tabla
	 */
	@Override
	public int getSize() {
		return tabla.length;
	}

	/**
	 * Asignar posicion por el hashCode del elemento,
	 * si posicion esta ocupada busco  otra posicion, si esta 
	 * vacio a�ado y termino, si esta borrado tambien.
	 * Estado a lleno.
	 * @return -2 si elemento es null, -1 si no se encuentra posicion (tam tabla)
	 * 	0 si lo a�ade.
	 */
	@Override
	public int add(T elemento) {
		if(elemento==null) return -2;
		if(numElementos == getSize()) return -1;
		
		int hash = fHash(elemento); //posicion del hash
		int intentos = 0; //numero de intentos
		
		while(intentos<= getSize()) {

			if(tipoExploracion==1) {//LINEAL
				int pos = (hash + intentos) % getSize();
				if(tabla[pos].getStatus()==HashNode.VACIO) { //si ta vacio o ( borrado y es igual)
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(HashNode.LLENO);
					numElementos++;
					reDispersion();
					return 0;
				}
				else if( tabla[pos].getStatus()==HashNode.BORRADO) { 
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(HashNode.LLENO);
					numElementos++;
					reDispersion();
					return 0;
				}
				intentos++;
			}
			
			else if(tipoExploracion==2) { //CUADRATICO
				int pos = (hash + (intentos*intentos)) % getSize();
				if(tabla[pos].getStatus()==HashNode.VACIO) {
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(HashNode.LLENO);
					numElementos++;
					reDispersion();
					return 0;
				}
				else if(tabla[pos].getStatus()==HashNode.BORRADO) { 
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(HashNode.LLENO);
					numElementos++;
					reDispersion();
					return 0;
				}
				intentos++;
			}
			
			
			else if(tipoExploracion==3) { //DISPERSION DOBLE
				int pos = (hash + intentos * (previousPrimeNumber(getSize()) - hash) % getSize()) % getSize();
				
				if(tabla[pos].getStatus()==HashNode.VACIO) {
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(1);
					numElementos++;
					reDispersion();
					return 0;
				}
				else if( tabla[pos].getStatus()==HashNode.BORRADO) { 
					tabla[pos].setInfo(elemento);
					tabla[pos].setStatus(HashNode.LLENO);
					numElementos++;
					reDispersion();
					return 0;
				}
				intentos++;
			}
			
		}
		
		return -2;//no encuentra posicion
	}

	/**
	 * Metodo que busca en la tabla el elemento dado por parametro.
	 * @param elemento a buscar
	 * @return null si no lo encuetra o el parametro es null, el elemento si lo encuentra
	 */
	@Override
	public T find(T elemento) {
		if(elemento == null) return null;
		
		int hash = fHash(elemento);
		int intentos = 0;
		int pos = 0;
		
		if(tipoExploracion==1)
			pos = (hash + intentos) % getSize();
		else if(tipoExploracion == 2)
			pos = (hash + (intentos*intentos)) % getSize();
		else if( tipoExploracion == 3)
			pos = (hash + intentos * (previousPrimeNumber(getSize()) - hash) % getSize()) % getSize();
		
		while(tabla[pos].getStatus() != HashNode.VACIO && intentos <= getSize() && pos >= 0) { 
			if (tabla[pos].getStatus() == HashNode.LLENO && tabla[pos].getInfo().equals(elemento))
				return tabla[pos].getInfo(); //lo encuentra
			
			if(tipoExploracion==1)
				pos = (hash + intentos) % getSize();
			else if(tipoExploracion == 2)
				pos = (hash + (intentos*intentos)) % getSize();
			else if( tipoExploracion == 3)
				pos = (hash + intentos * (previousPrimeNumber(getSize()) - hash) % getSize()) % getSize();
			
			intentos++;
		}
		
		return null;// no lo encuentra
	}

	/**
	 * Metodo que borra un elemento de la tabla.
	 * @param el elemento a borrar
	 * @return -2 si el elemento es null, -1 si no esta en la tabla,
	 *  0 si lo borra correctamente
	 */
	@Override
	public int remove(T elemento) {
		if(elemento == null)  return -2;
		if (find(elemento) == null) return -1;
		

		int intentos = 0;
		int hash = fHash(elemento);
		int pos = 0;
		
		if(tipoExploracion==1)
			pos = (hash + intentos) % getSize();
		else if(tipoExploracion == 2)
			pos = (hash + (intentos^intentos)) % getSize();
		else if( tipoExploracion == 3)
			pos = (hash + intentos * (previousPrimeNumber(getSize()) - hash) % getSize()) % getSize();
		
	
		
		while(tabla[pos].getStatus() != HashNode.VACIO) {
			
			if(tabla[pos].getStatus() == HashNode.LLENO && tabla[pos].getInfo().equals(elemento)) {
				tabla[pos].remove();
				numElementos--;
				inverseRedispersion();
				return 0;
			}
			intentos++;
			
			if(tipoExploracion==1)
				pos = (hash + intentos) % getSize();
			else if(tipoExploracion == 2)
				pos = (hash + (intentos*intentos)) % getSize();
			else if( tipoExploracion == 3)
				pos = (hash + intentos * (previousPrimeNumber(getSize()) - hash) % getSize()) % getSize();
			
		}
		
		return 0;
	}

	/**
	 * Metodo toString que devuelve un string con el estado de la tabla.
	 */
	@Override
	public String toString() {
		StringBuilder cadena = new StringBuilder();
		for (int i = 0; i < getSize(); i++) {
			cadena.append(tabla[i].toString());
			cadena.append(";");
		}
		cadena.append("[Size: ");
		cadena.append(getSize());
		cadena.append(" Num.Elems.: ");
		cadena.append(getNumOfElements());
		cadena.append("]");
		return cadena.toString();
	}

	/**
	 * Metodo que aumenta el tama�o de la tabla al doble para mantener un 
	 * valor aceptable entre el numero de elementos y el tama�o de la tabla.
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void reDispersion() {
		if(numElementos/(tabla.length * 1.0) > maxlf ) {
			HashNode<T>[] supp = tabla; 
			int tamano = nextPrimeNumber(tabla.length*2);
			this.tabla =(HashNode<T>[]) Array.newInstance(HashNode.class, tamano);
			numElementos = 0;
		
			for (int i = 0; i < tamano; i++) {
				tabla[i] = new HashNode<T>();
			}
		
			for(int i=0; i<supp.length; i++) {
				if(supp[i].getStatus()==HashNode.LLENO) {
					this.add(supp[i].getInfo());
				}
			}
		}
		
	}

	/**
	 * Metodo que disminuye el tama�o de la tabla a la mitad para mantener un 
	 * valor aceptable entre el numero de elementos y el tama�o de la tabla.
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void inverseRedispersion() {
		if(numElementos/(tabla.length * 1.0) < minlf ) {
			HashNode<T>[] supp = tabla;
			int tamano;
			if(!isPositivePrime(tabla.length/2)) //si no es primo
				tamano = previousPrimeNumber(tabla.length/2);
			else tamano= tabla.length/2; //si es primo
			this.tabla =(HashNode<T>[]) Array.newInstance(HashNode.class, tamano);
			numElementos = 0;
		
			for (int i = 0; i < tamano; i++) {
				tabla[i] = new HashNode<T>();
			}
		
			for(int i=0; i<supp.length; i++) {
				if(supp[i].getStatus()==HashNode.LLENO) {
					this.add(supp[i].getInfo());
				}
			}
		}
	}

}
