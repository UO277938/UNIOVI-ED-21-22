package BST;

public class BSTNode <T extends Comparable <T>>{

	private T info;           //contenido nodo generico
	private BSTNode<T> left;  //nodo izquierdo
	private BSTNode<T> right; //nodo derecho
	
	/**
	 * Constructor que inicializa el nodo raiz con
	 * 	el contendio del par�metro y sus hijos izq. y dcha. a null
	 * @param clave contenido nodo raiz
	 */
	public BSTNode(T clave) {
		setInfo(clave);
		this.left=null;
		this.right=null;
	}
	
	/**
	 * Metodo que asigna al atributo info la dada por parametro
	 * @param clave 
	 */
	public void setInfo(T clave) {
		this.info=clave;
	}
	
	/**
	 * Metodo que devuelve el valor del atributo info
	 * @return valor de info
	 */
	public T getInfo() {
		return this.info;
	}
	
	public void setLeft(BSTNode<T> nodo) {
		this.left=nodo;
	}
	
	public void setRight(BSTNode<T> nodo) {
		this.right=nodo;
	}
	
	public BSTNode<T> getLeft(){
		return this.left;
	}
	
	public BSTNode<T> getRight(){
		return this.right;
	}
	
	/**
	 * Metodo toString que utiliza el toString de info
	 */
	public String toString() {
		return info.toString();
	}
}
