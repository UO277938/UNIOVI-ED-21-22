package Hash;

public abstract class AbstractHash <T>{

	abstract public int getNumOfElements();
	
	abstract public int getSize();
	
	abstract public int add(T elemento);
	 
	abstract public T find(T elemento);
	
	abstract public int remove(T elemento);
	
	abstract public String toString();
	
	/**
	 * Nos devuelve la posicion en la tabla teniendo en cuenta su hashCode
	 * @param elemento a calcular su hashCode
	 * @return la posicion a la que corresponde a la tabla
	 */
	protected int fHash(T elemento) {
		int pos = elemento.hashCode()%getSize();
		if(pos<0) return pos+getSize();
		else return pos;
	}
	
	/**
	 * Determina si un numero es primo positivo o no
	 * @param numuero a saber si es primo
	 * @return true si es primo, false si no
	 */
	protected boolean isPositivePrime(int numero) {
		if( numero == 0 || numero==1 || numero==4) return false;
		for(int i=2; i<numero/2;i++) {
			if(numero%i==0)
				return false;
		}return true;
	}
	
	/**
	 * Nos devuelve el siguiente numero primo a partir de uno dado
	 * @param numero desde el que se busca el primo
	 * @return el numero primo
	 */
	protected int nextPrimeNumber(int numero) {

		numero++;
		while(!isPositivePrime(numero)) {
			numero++;
		}
		return numero;	
	}
	
	/**
	 * Nos devuelve el primo anterior de un numero
	 * @param numero a buscar el primo
	 * @return el primo anterior
	 */
	protected int previousPrimeNumber(int numero) {
		numero--;
		while(!isPositivePrime(numero)) {
			numero--;
		}
		return numero;
	}
	
	abstract protected void reDispersion();
	
	abstract protected boolean inverseRedispersion();
	
}
