package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import Paquete.Graph;

class Tests {

	@Test
	public void testsExistsNode() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		
		grafos.addNode(3);
		grafos.addNode(8);
		
		assertTrue(grafos.existsNode(3));
		assertFalse(grafos.existsNode(5));
	}
	
	@Test
	public void testsAddNode() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		
		assertEquals(grafos.addNode(3),0); //hay hueco y no existe
		
		assertEquals(grafos.addNode(3),-1); //hay hueco pero existe
		 
		assertEquals(grafos.addNode(8),0); //hay hueco y no existe
		
		assertEquals(grafos.addNode(3),-3);  //no hay hueco y existe
		
		assertEquals(grafos.addNode(5),-2); //no hay hueco y no existe
		
		assertTrue(grafos.existsNode(3));
		assertTrue(grafos.existsNode(8));
	}
	
	@Test
	public void testsExistEdge() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		grafos.addNode(3);
		grafos.addNode(8);
		
		grafos.addEdge(3, 8, 5);
		
		assertTrue(grafos.existEdge(3, 8));
		assertFalse(grafos.existEdge(1, 4));
		
		
	}
	
	@Test
	public void testsGetEdge() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		grafos.addNode(3);
		grafos.addNode(8);
		
		assertEquals(grafos.getEdge(3, 8), -4);  //no existe arista
		
		grafos.addEdge(3, 8, 5);
		
		assertEquals(grafos.getEdge(3, 8), 5); //todo bien
		assertEquals(grafos.getEdge(5, 8), -1); //no existe fuente
		assertEquals(grafos.getEdge(3, 4), -2); // no existe destino
		assertEquals(grafos.getEdge(1, 10), -3); //no existen ninguno
		
	}
	
	@Test
	public void testsAddEdge() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		grafos.addNode(3);
		grafos.addNode(8);
		
		assertEquals(grafos.addEdge(3, 8, -20), -8); //peso no valido
		
		assertEquals(grafos.addEdge(3, 8, 5), 0); //todo bien
		assertEquals(grafos.addEdge(5, 8, 5), -1); //no existe fuente
		assertEquals(grafos.addEdge(3, 4, 5), -2); // no existe destino
		assertEquals(grafos.addEdge(1, 10, 5), -3); //no existen ninguno
		assertEquals(grafos.addEdge(3, 8, 5), -4);  //ya existe 
		
	}
	
	@Test
	public void testsRemoveEdge() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		grafos.addNode(3);
		grafos.addNode(8);
		
		assertEquals(grafos.removeEdge(5, 8), -1); //no existe fuente
		assertEquals(grafos.removeEdge(3, 4), -2); // no existe destino
		assertEquals(grafos.removeEdge(1, 10), -3); //no existen ninguno
		assertEquals(grafos.removeEdge(3, 8), -4);  //no existe arista 
		
		grafos.addEdge(3, 8, 5);
		
		assertEquals(grafos.removeEdge(3, 8),0); //borra correctamente
	}
	
	@Test
	public void testsRemoveNode() {
		Graph<Integer> grafos = new Graph<Integer>(2);
		grafos.addNode(3);
		grafos.addNode(8);
		
		assertEquals(grafos.removeNode(5), -1); //no existe
		assertEquals(grafos.removeNode(3), 0); // borra
		assertEquals(grafos.removeNode(3), -1); //no puede
		assertEquals(grafos.removeNode(8), 0);  //borra correctamente
	}
	
	@Test
	public void testsDijkstra() {
		Graph<Integer> grafos = new Graph<Integer> (5);
		Graph<Integer> graf2 = new Graph<Integer> (5);
		
		grafos.addNode(1);
		grafos.addNode(2);
		grafos.addNode(3);
		grafos.addNode(4);
		grafos.addNode(5);
		
		
		grafos.addEdge(1, 2, 1);
		grafos.addEdge(1, 4, 3);
		grafos.addEdge(1, 5, 10);
		grafos.addEdge(2, 3, 5);
		grafos.addEdge(3, 5, 1);
		grafos.addEdge(4, 3, 2);
		grafos.addEdge(4, 5, 6);
		
		
		double[] h = new double[5];
		h[0] = 0;  h[1] = 1;
		h[2] = 5;  
		h[3] = 3;     h[4] = 6;
		
		
		
		assertArrayEquals(grafos.dijkstra(1), h );
		
		
	}

}
