package Paquete;

import java.text.DecimalFormat;

public class Graph<T> {

	private double[][] weights; // pesos de la arista
	private boolean[][] edges;  // matriz de aristas
	private T[] nodes;          // nodos, lista
	private int size;
	
	private double[][] a;		//dijkstra
	private T[][] p;			//dijkstra
	
	private String cadenaDFS;
	
	public Graph(int dimension) {
		size= 0;
		edges = new boolean[dimension][dimension];
		weights = new double[dimension][dimension];
		nodes = (T[]) new Object[dimension];
	}
	
	public int getSize() {
		return size;
	}
	
	public double[][] getWeights() {
		return weights;
	}
	
	public boolean[][] getEdges(){
		return edges;
	}
	
	public int getNode(T node) {
		if(node!=null) {
			for(int i=0;i<size;i++) {
				if(node.equals(nodes[i]))
					return i;
			}
		}return -1;
	}
	
	/**
	 * Metodo que devuelve true si existe nodo en nodes[]
	 * @param node a buscar
	 * @return true si existe
	 */
	public boolean existsNode(T node) {
		if(node!=null) {
			for(int i=0;i<size;i++) {
				if(node.equals(nodes[i]))
					return true;
			}
		}return false;
	}
	
	/**
	 * A�ade un nodo a nodes[] 
	 * @param node a a�adir
	 * @return 0 si lo a�ade, -1 si existe ya existe el nodo y tiene hueco, 
	 * 			-2 si no existe ya el nodo y no entra, -3 si ya existe el nodo y no entra,
	 * 				-4 si el nodo es nulo
	 */
	public int addNode(T node) {
		if(existsNode(node) && getSize()==nodes.length)//existe y no entra
			return -3;
		if(existsNode(node) && getSize()<nodes.length) //existe y entra
			return -1;
		if(!existsNode(node) && getSize()==nodes.length) //no existe y no entra
			return -2;
		if(node.equals(null)) //no es valido
			return -4;
		nodes[size] = node; //es valido y lo inserta
		for(int i=0; i<=size;i++) {
			edges[size][i] = false;
			weights[size][i] = 0;
			edges[i][size] = false;
			weights[i][size] = 0;
		}
		size++;
		return 0;
	}
	
	/**
	 * Devuelve true si existe arista entre fuente y destino
	 * @param source fuente
	 * @param target destino
	 * @return true si existe false si no
	 */
	public boolean existEdge(T source, T target) {
		if(!existsNode(source) || !existsNode(target)) //no existe alguno
			return false;
		int fuente = getNode(source);
		int objetivo = getNode(target);
		return edges[fuente][objetivo]; //true si existe, false si no
	}
	
	/**
	 * Metodo que nos da el peso de la arista entre dos nodos
	 * @param source fuente
	 * @param target destino
	 * @return -1 si no existe origen, -2 si no existe destino, -3 si no existe ninguno
	 * 			el peso de la arista si no
	 */
	public double getEdge(T source, T target) {
		if(!existsNode(source) && !existsNode(target)) //no existe ninguno
			return -3;
		if(!existsNode(source)) //no existe source
			return -1;
		if(!existsNode(target)) //no existe target
			return -2;
		if(!existEdge(source, target)) return -4; //no existe la arista
		
		int fuente = getNode(source);
		int objetivo = getNode(target);
		return weights[fuente][objetivo]; //devuelve el peso de esa arista
	}
	
	/**
	 * Metodo que a�ade una arista entre dos nodos y un peso
	 * @param source Nodo origen
	 * @param target Nodo objectivo
	 * @param weight Peso entre ambos
	 * @return 0 si a�ade la arista, -1 no existe source, -2 no existe target
	 * 			-3 no existe ninguno, -4 ya existe la ariista, -8 peso invalido
	 */
	public int addEdge(T source, T target, double weight) {
		if(weight<=0) return -8; //peso no valido
		
		if(!existsNode(source) && !existsNode(target)) //no existe ninguno
			return -3;
		if(!existsNode(source)) //no existe source
			return -1;
		if(!existsNode(target)) //no existe target
			return -2;
		
		if(existEdge(source, target)) return -4; //ya existe la arista
		
		int fuente = getNode(source);
		int objetivo = getNode(target);
		edges[fuente][objetivo]=true;
		weights[fuente][objetivo] = weight;
		return 0;
	}
	
	/**
	 * 
	 * @param source Nodo fuente
	 * @param target Nodo objetivo
	 * @return 0 si borra la arista, -1 si no existe source, -2 no existe target
	 * 			-3 no existe ninguno, -4 no existe la arista
	 */
	public int removeEdge(T source, T target) {
		if(!existsNode(source) && !existsNode(target)) //no existe ninguno
			return -3;
		if(!existsNode(source)) //no existe source
			return -1;
		if(!existsNode(target)) //no existe target
			return -2;
		
		if(!existEdge(source, target)) return -4; //no existe la arista
		
		int fuente = getNode(source);
		int objetivo = getNode(target);
		edges[fuente][objetivo]=false;
		weights[fuente][objetivo] = 0;
		return 0;
	}
	
	/**
	 * Borra el nodo dado por parametro, si no se puede -1
	 * @param node Nodo a borrar
	 * @return 0 sii borra el nodo, -1 si no
	 */
	public int removeNode(T node) {
		if(existsNode(node)) { //si existe
			int j = getNode(node);
			if(j!=size) //si no es el ultimo nodo
				nodes[j] = nodes[size-1]; //borramos el nodo de la posicion
												// y ponemos el ultimo nodo
			for(int i=0; i<size;i++) {
				edges[i][j]=edges[i][size-1];
				edges[j][i]=edges[size-1][i];
				weights[j][i]=weights[size-1][i];
				weights[i][j]=weights[i][size-1];
			}
			edges[j][j] = edges[size-1][size-1];
			weights[j][j] = weights[size-1][size-1];
			return 0;
		}
		return -1;
	}
	
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		String cadena = "";
		cadena += "NODOS\n";
		for (int i = 0; i < size; i++) {
		cadena += nodes[i].toString() + "\t";
		}
		cadena += "\n\nARISTAS\n";
		for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
		if (edges[i][j])
		cadena += "T\t";
		else
		cadena += "F\t";
		}
		cadena += "\n";
		}
		cadena += "\nPESOS\n";
		for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
		cadena += (edges[i][j]?df.format(weights[i][j]):"-") + "\t";
		}
		cadena += "\n";
		}
		return cadena;
	}
	
	/**
	 * Metodo dijkstra que nos da el camino de un nodo al resto de nodos
	 * @param source nodo origen
	 * @return una lista de los costes a las otros nodos
	 */
	public double[] dijkstra (T source) {
		if(source==null || !existsNode(source)) return null; //si no existe source
		
		boolean[] S = inicializaS(source); //size
		T[] P = inicializaP(source);  //nodos
		double[] D = inicializaD(source);  //pesos
		
		int W = getPivote(D,S);  //busco el pivote con menor coste del vector D
		
		while(W!=-1) {
			S[W] = true; //ese nodo ha sido alcanzado
			for(int i=0;i<size;i++) { 
				if(S[W] && edges[W][i]) {//si el nodo alcanzado, compruebo que es menor el coste
					if(D[W] + weights[W][i] < D[i]) { 
						D[i] = D[W] + weights[W][i];
						P[i]= nodes[W];
					}
				}
			}
			W = getPivote(D, S);
		}
		return D;
	}
	
	/**
	 * Metodo que inicializa el vector de pesos, pone la posicion del nodo origen a 0.0 ,
	 * 	el peso si existe arista o infinito si no existe
	 * @param node origen
	 * @return el vector
	 */
	private double[] inicializaD(T node) {
		double[] d = new double[size];
		int nodePosition = getNode(node);
		for(int i=0;i<size;i++) {
			if(nodePosition == i) //a
				d[i] = 0;
			else if (edges[nodePosition][i]) //si hay arista ponemos el peso
				d[i] = new Double(weights[nodePosition][i]);
			else d[i] = Double.POSITIVE_INFINITY; //sino infinito
		}
		return d;
	}
	
	/**
	 * Metodo que inicializa el vector de nodos para dijkstra, si existe arista
	 * 	entre nodo origen y el resto de nodos lo a�ade a la lista de dijkstra,
	 * 	 si no existe lo pone a null
	 * @param node origen
	 * @return el vector de nodos para dijkstra
	 */
	private T[] inicializaP(T node) {
		T[] p = (T[]) new Object[size];
		for(int i=0;i<size;i++) {
			if(existEdge(node,nodes[i])) //si hay arista entre
				p[i] = nodes[i];
			else p[i] = null; //si no
		}return p;
	}
	/**
	 * Metodo que inicializa un vector booleano que pone el origen a true y el resto a false
	 * @param source origen
	 * @return el vector booleano
	 */
	private boolean[] inicializaS(T source) {
		int j = getNode(source);
		boolean[] S= new boolean[getSize()];
		for(int i=0;i<S.length;i++)
			S[i] = false; //el resto no se visitaron => false
		S[j]= true; //el mismo => true
		return S;
	}
	
	/**
	 * Metodo que devuelve la posicion del pivote o -1 si no encuentra
	 * @param d vector de pesos D
	 * @param s vector boolean S
	 * @return pos del pivote si lo encuentra
	 */
	public int getPivote(double[] d, boolean[] s) {
		double menorCoste = Double.MAX_VALUE;
		int ret = -1;
		for(int i=0; i<s.length; i++) {
			if(!s[i] & d[i]<menorCoste) {
				menorCoste = d[i];
				ret = i;
			}
		}return ret;
	}
	
	public void printDouble(double[] d) {
		for(int i=0; i<d.length;i++)
			System.out.print(d[i]);
	} 
	
	/**
	 * Metodo de Floyd que encuentra el camino m�nimo desde cualquier nodo a todos los dem�s
	 * @return 0 si se ejecuta; -1 si no se inicializan A o P, o si el tama�o es menor que 1
	 */
	public int floyd() {
		if(size<=0) return -1;
		a = inicializaA();
		p = inicializaP();
		if(a==null||p==null) return -1; 
		
		for(int pivot = 0;pivot<size;pivot++) {
			for(int source=0;source<size;source++) {
				for(int target=0;target<size;target++) {
					if( (a[source][pivot] + a[pivot][target]) < a[source][target]) {
						a[source][target] = a[source][pivot]+ a[pivot][target];
						p[source][target] = nodes[pivot];
					}
				}
			}
		}
		return 0;
	}
	
	/**
	 * Inicializa la matriz de nodos para Floyd
	 * @return la matriz de nodos
	 */
	private T[][] inicializaP() {
		@SuppressWarnings("unchecked")
		T[][] p = (T[][]) new Object[size][size];
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(existEdge(nodes[i], nodes[j])) 
					p[i][j]=nodes[i];
				else
					p[i][j] = null;
			}
		}return p;
		
	}
	
	/**
	 * Iniciliza la matriz de pesos para Floyd
	 * @return la matrid de pesos
	 */
	private double[][] inicializaA() {
		double[][] a = new double[size][size];
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(i==j) 
					a[i][j]=0;
				
				else if(existEdge(nodes[i], nodes[j])) 
					a[i][j]= weights[i][j];
				
				else a[i][j]=Double.POSITIVE_INFINITY;
			}
		}return a;
	}

	public double[][] getFloydA(){
		return a;
	}
	
	public T[][] getFloydP(){
		return p;
	}
	
	/**
	 * Metodo que nos calcula el camino minimo entre dos nodos
	 * @param nodoOrigen origen
	 * @param nodoDestino destino
	 * @return el coste del camino o -1 si no se pudo ejecutar floyd
	 */
	protected double minCostPath(T nodoOrigen, T nodoDestino) {
		if(floyd()<0) return -1;
		
		double[][] n = getFloydA();
		
		return n[getNode(nodoOrigen)][getNode(nodoDestino)];
	}
	
	public String floydToString() {
		int numNodes=size; 
		String cadena=" "; 
		DecimalFormat df = new DecimalFormat("#.##"); 
		
		 double[][] aFloyd = getFloydA(); 
	        if (aFloyd != null) { 
	            cadena += "\nAFloyd\n"; 
	            for (int i = 0; i < numNodes; i++) { 
	                for (int j = 0; j < numNodes; j++) { 
	                    cadena += df.format(aFloyd[i][j]) + "\t"; 
	                } 
	                cadena += "\n"; 
	            } 
	        } 
	  
	        T[][] pFloyd = getFloydP(); 
	        if (pFloyd != null) { 
	                cadena += "\nPFloyd\n"; 
	            for (int i = 0; i < numNodes; i++) { 
	                for (int j = 0; j < numNodes; j++) { 
	                	if (pFloyd[i][j]==null) cadena+="-"+ "\t";
	                	
	                	else cadena += pFloyd[i][j].toString() + "\t"; 
	                } 
	                cadena += "\n"; 
	            } 
	        } 
	        return cadena; 
	}
	
	public String path(T nodoOrigen, T nodoDestino) {
		String ret = "";

		if(nodoOrigen.equals(nodoDestino)) {
			return ret+= nodoOrigen; 
		}
		else if(minCostPath(nodoOrigen, nodoDestino)<0)
			return ret += nodoOrigen + "\t" + Double.POSITIVE_INFINITY + "\t" + nodoDestino;
		else {
			ret += nodoOrigen;
			ret += intermedioPath(nodoOrigen,nodoDestino);
			ret += nodoDestino;
		}return ret;
	}
	
	private String intermedioPath(T i, T j) {
		T k = getFloydP()[getNode(i)][getNode(j)];
		if(k!=null && k!=i && k!=j) 
			return intermedioPath(i,k) 
					+ k.toString() + intermedioPath(k, j);
		else return "\t(" + getFloydA()[getNode(i)][getNode(j)] + ")\t" ;
	}
	
	/**
	 * Metodo que recorre a partir de uno todos los dem�s recursivamente
	 * @param nodo origen
	 * @return una cadena con los nodos visitados o vacia si no existe el nodo
	 */
	public String recorridoProfundidad(T nodo) {
		cadenaDFS ="";
		if(nodo==null)
			return cadenaDFS;
		boolean visitados[]=new boolean[size]; //crea vector boolean de los visitados
		visitados = resetVisited(visitados); //se inicializa todos a false
		recursivoProfundidad(nodo, visitados); //se llama recursivamente a otro metodo
		return cadenaDFS;
	}
	
	/**
	 * Metodo recursivo que 
	 * @param nodo origen
	 * @param visitados vector de visitados
	 */
	public void recursivoProfundidad(T nodo, boolean[] visitados) {
		
		int posicion = getNode(nodo);
		
		cadenaDFS+=nodo.toString()+"\t";
		setVisited(visitados,posicion,true); //nodo origen a true
		for(int i=0;i<size;i++) {
			if(!visitados[i] && edges[posicion][i]) { //si no ha sido visitado y hay camino
				recursivoProfundidad(nodes[i], visitados); //llama recursivo con nuevo origen
			}
		}
	}
	
	/**
	 * Metodo que resetea el vector, todos a false menos el origen
	 * @param visitados
	 * @param posicion
	 * @return el vector de visitados
	 */
	private boolean[] resetVisited(boolean[] visitados) {
		for(int i=0;i<size;i++) 
			setVisited(visitados, i, false);
		
		return visitados;
	}
	
	private void setVisited(boolean[] visitado, int index, boolean cond) {
		visitado[index] = cond;
	}

}
